<?php


//define (DB_USER, "root");
//define (DB_PASSWORD, "");
//define (DB_DATABASE, "quiz");
//define (DB_HOST, "localhost");


//$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
    $dbhost	= "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "quiz";

	$connection = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
    if(mysqli_connect_errno()){ 
		die("Database Connection Failed" . mysqli_connect_error() . "(" . mysqli_connect_errno() . ")");
	}





?>

